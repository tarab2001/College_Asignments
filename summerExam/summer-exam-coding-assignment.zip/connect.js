module.exports = {
    database: {
        url: "mongodb+srv://TBdbUser:Liverpool123@cluster0.tbkte.mongodb.net/test"
    }
}