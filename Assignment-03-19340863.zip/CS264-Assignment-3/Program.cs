﻿/*
For the redo/undo functionality I have created a 2 lists, one that is used to add the shapes to as the user wishes 
and one that stays empty until they call the undo function that is empty to begin. When a user decides to undo the 
last shape I then get the last shape in the 'shapes' list and remove it from that list and add it to the empty 
'unodRedo' list. When a user decides to redo the last function I get the last shape in the 'undoRedo' list and 
remove it from this list and add it to the 'shapes' list again
Operating System = Windows IDE= VS Code
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace CS264_Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            var r = new Random();
            String s = "";//string we add to SVG file
            Console.WriteLine("Canvas created. Use commands to add shapes to canvas!");//line to prompt user
            String s1 = Console.ReadLine();//read shape from user
            List<Shape> shapes = new List<Shape>();//list to add shapes too
            List<Shape> undoRedo = new List<Shape>(); //list to handle undo/redo
            String SVGOpen = "<svg viewBox=\"0 0 100 100\" + xmlns=\"http://www.w3.org/2000/svg\">";//first line of SVG file
            s = s + SVGOpen;//add to empty string


            while(s1 != "Q"){//take user input while they add shapes
                if(s1.Split(' ')[0] == "A"){
                    String shapeA = s1.Split(' ')[1]; //shape user entered
                    if(shapeA == "Circle"){
                        //get circle info from user
                        int r1 = r.Next(100); //random point
                        int cx = r.Next(100); //random point
                        int cy = r.Next(100); //random point

                        Circle c1 = new Circle(r1,cx,cy, "grey","black", "1"); //call cirlce class to create circle
                        shapes.Add(c1); //add to list
                        Console.WriteLine("Circle (R=" + r1 + ",X=" + cx + ",Y=" + cy + ") added to canvas");
                    }
                    else if (shapeA == "Rectangle"){
                        //get rectangle info from user
                        int x = r.Next(100); //random point
                        int y = r.Next(100); //random point
                        int w = r.Next(100); //random point
                        int h = r.Next(100); //random point

                        Rec r1 = new Rec(x,y,w,h,"red","black","2"); //create rec from rectangle class
                        shapes.Add(r1); //add to list
                        Console.WriteLine("Rectangle (X=" + x + ",Y=" + y + ",W=" + w + ",H=" + h + ") added to canvas");
                    }
                    else if(shapeA == "Ellipse"){
                        //get elipse info from user
                        int rx = r.Next(100); //random point
                        int ry = r.Next(100); //random point
                        int cx = r.Next(100); //random point
                        int cy = r.Next(100); //random point

                        Ellipse e1 = new Ellipse(rx,ry,cx,cy,"yellow","black","2"); //create ellipse from class and method
                        shapes.Add(e1); //add to list
                        Console.WriteLine("Ellipse (RX=" + rx + ",RY=" + ry + ",X=" + cx + ",Y=" + cy + ") added to canvas");
                    }
                    else if(shapeA == "Line"){
                        //get line points from user
                        int x1 = r.Next(100); //random point
                        int y1 = r.Next(100); //random point
                        int x2 = r.Next(100); //random point
                        int y2 = r.Next(100); //random point

                        Line l1 = new Line(x1,y1,x2,y2,"black"); //from line class create line
                        shapes.Add(l1); //add to list
                        Console.WriteLine("Line (X1=" + x1 + ",Y1=" + y1 + ",X2=" + x2 + ",Y2=" + y2 + ") added to canvas");
                    }
                    else if(shapeA == "Polyline"){
                        //get polyline info from user

                        List<String> points = new List<String>();//list of points
                        int listLen = r.Next(10);//number of points
                        for(int i = 0; i < listLen; i++){//add random points to list
                            int a = r.Next(100);
                            int b = r.Next(100);
                            String point = a.ToString() + "," + b.ToString();//convert to string
                            points.Add(point);//add to list
                        }
                        Polyline p1 = new Polyline(points,"none", "black");//from polyline class create new polyline
                        shapes.Add(p1);//add to list
                        string string1 = "";
                        foreach(var p in points){
                            string1 = string1 + " " + p; 
                        }
                        Console.WriteLine("Polyline (" + string1 + ") added to canvas");
                    }
                    else if(shapeA == "Polygon"){
                        List<String> points = new List<String>(); //list of points
                        int listLen = r.Next(10); //number of points
                        for(int i = 0; i < listLen; i++){ //add random points to list
                            int a = r.Next(100);
                            int b = r.Next(100);
                            String point = a.ToString() + "," + b.ToString(); //convert to string
                            points.Add(point); //add to list
                        }
                        Polygon pol1 = new Polygon(points,"none","black");//from polyline class create new polyline
                        shapes.Add(pol1);//add to list
                        string string2 = "";
                        foreach(var p in points){
                            string2 = string2 + " " + p; 
                        }
                        Console.WriteLine("Polygon (" + string2 + ") added to canvas");
                    }
                    else{
                        Console.WriteLine("Shape not recognised");
                    }

                }
                else if(s1 == "U"){
                   int len = shapes.Count-1; //length of shape list
                   undoRedo.Add(shapes[len]);//add last shapes to new list
                   shapes.Remove(shapes[len]); //remove shapes from main list
                }
                else if(s1 == "R"){
                    int len = undoRedo.Count-1; //length of undo list
                    shapes.Add(undoRedo[len]); //add last element of undo list to shapes list
                    undoRedo.Remove(undoRedo[len]);//remove shape from undo list
                }
                else if(s1 == "C"){
                    shapes.Clear(); //clear canvas
                }
                else if(s1 == "D"){
                    s = create(shapes);
                    Console.WriteLine(s);
                }
                else if(s1 == "H"){
                    //user menu
                    Console.WriteLine("Commands: ");
                    Console.WriteLine("         H            Help- diplays this message");
                    Console.WriteLine("         A <shape>    Add <shape> to canvas");
                    Console.WriteLine("         U            Undo last operation");
                    Console.WriteLine("         R            Redo last operation");
                    Console.WriteLine("         C            Clear canvas");
                    Console.WriteLine("         D            Display canvas");
                    Console.WriteLine("         Q            Quit application");
                }
                else if(s1 == "S"){
                    s = create(shapes);
                    File.WriteAllText(@"C:\Users\tarab\CS264-Assignment-3\Shapes.SVG", s); //create SVG file
                }
                else{
                    Console.WriteLine("Input not recognsied!!");
                }
                s1 = Console.ReadLine(); //read next line from user
            }
            Console.WriteLine("Goodbye!");
        }

        public static String create(List<Shape> shapes){
            String s = "<svg viewBox=\"0 0 100 100\" + xmlns=\"http://www.w3.org/2000/svg\">";
            foreach (var shape in shapes)
                    {
                        s = s + Environment.NewLine.PadLeft(15) +  shape.Create(); //add shape to string
                    }
                    string SVGClose = "</svg>"; //last line of SVG file
                    s = s + Environment.NewLine + SVGClose; // add closing line to string
            //File.WriteAllText(@"C:\Users\tarab\CS264-Assignment-3\Shapes.SVG", s); //create SVG file
            return s;
        }
    }

    public class Shape{
        public Shape(){
        }

        public virtual String Create(){//basic create class
            String s2 = "";
            return s2;

        }
    }
    public class Circle : Shape{
        public int r;//radius
        public int cx; //center x pos
        public int cy; //center y pos
        public string fill = "";//colour of shape
        public string stroke = ""; //line colour
        public string stroke_w = ""; //stroke width
        public Circle(){//set r, cx & cy
            r = 10; 
            cx = 10;
            cy = 10;
            fill = "grey";
            stroke = "black";
            stroke_w = "1";
        }
        public Circle(int r, int cx, int cy, string s,string s1,string s2){ //get r,cx,cy,fill,stroke,stroke-width
            this.r = r;
            this.cx = cx;
            this.cy = cy;
            this.fill = s;
            this.stroke = s1;
            this.stroke_w = s2;
        }
        public override String Create(){//create Circle in SVG file
            String s1 = "<circle cx=\"" + this.cx + "\" cy=\"" + this.cy + "\" r=\"" + this.r + "\" stroke =\"" + this.stroke + "\" stroke-width=\"" + this.stroke_w + "\" fill=\"" + this.fill +"\"/>";
            return s1;
        }
    }
    public class Rec : Shape{
        public int x; //x pos
        public int y; //y pos
        public int w; //width
        public int h;//height
        public string fill = "";//colour of shape
        public string stroke = ""; //line colour
        public string stroke_w = ""; //stroke width
        public Rec(){//set x,y,h,w
            x = 10;
            y = 10;
            w = 10;
            h = 10;
            fill = "red";
            stroke = "black";
            stroke_w = "2";
        }
        public Rec(int x,int y,int w,int h,string s,string s1,string s2){//get x,y,h,w
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.fill = s;
            this.stroke = s1;
            this.stroke_w = s2;
        }

        public override String Create(){//create Rectangle in SVG file
            String s1 = " <rect x=\""+ this.x + "\" y=\"" + this.y + "\" width=\"" + this.w + "\" height=\"" + this.h +"\"fill=\"" + this.fill + "\" stroke=\"" +this.stroke +"\"  stoke-width=\"" +this.stroke_w +"\"/>";
            return s1;
        }
    }

    public class Ellipse : Shape{
        public int rx;//radius x
        public int ry;//radius y
        public int cx;//center x
        public int cy;//center y
        public string fill = "";//colour of shape
        public string stroke = ""; //line colour
        public string stroke_w = ""; //stroke width 
        public Ellipse(){//set rx,ry,cx,cy
            rx = 10;
            ry =10;
            cx = 10;
            cy = 10;
        }
        public Ellipse(int rx, int ry, int cx, int cy,string s,string s1,string s2){//get rx,ry,cx,cy
            this.rx = rx;
            this.ry = ry;
            this.cx = cx;
            this.cy = cy;
            this.fill = s;
            this.stroke = s1;
            this.stroke_w = s2;
        }

        public override String Create(){//create Ellipse in SVG file
            String s1 = " <ellipse cx=\"" + this.cx + "\" cy=\"" + this.cy + "\" rx=\"" + this.rx + "\" ry=\"" + this.ry + "\" fill=\"" + this.fill + "\" stroke=\"" +this.stroke +"\"  stoke-width=\"" +this.stroke_w +"\"/>";
            return s1;
        }
    }

    public class Line : Shape{
        public int x1, x2, y1, y2;//points of line
        public string stroke = ""; //stroke of line
        public Line(){//set points
            x1 = 10;
            x2 = 20;
            y1 = 10;
            y2 = 20;
            stroke = "black";
        }
        public Line(int x1, int x2, int y1, int y2,string s){//get points
            this.x1 = x1;
            this.x2 = x2;
            this.y1 = y1;
            this.y2 = y2;
            this.stroke = s;
        }

        public override String Create(){//create Line in SVG file
            String s1 = " <line x1=\"" + this.x1 + "\" y1=\"" + this.y1 + "\" x2=\"" + this.x2 + "\" y2=\"" + this.y2 + "\" stroke=\"" + this.stroke + "\" />";
            return s1;
        }
    }

    public class Polyline : Shape{
        public string s5 = ""; //string for points
        public string fill,stroke;
        public Polyline(){            
        }
        public Polyline(List<String> l,string s, string s1){//add points from list to string           
            foreach(var point in l){
                this.s5 = this.s5 + " " + point;
            }
            this.fill = s;
            this.stroke = s1;
        }

        public override String Create(){//create Polyline in SVG file
            String s1 = "<polyline points=\"" + this.s5 + "\" fill=\"" + this.fill +"\" stroke=\"" + this.stroke + "\"/>"; 
            return s1;
        }
        
    }

    public class Polygon : Shape{
        public string s7 = "";//string for points
        public string fill,stroke;
        public Polygon(){

        }

        public Polygon(List<String> l2,string s, string s1){//add points from list to string
            foreach(var p in l2){
                this.s7 = this.s7 + " " + p;
            }
            this.fill = s;
            this.stroke = s1;
        }

        public override String Create(){//create Polygon in SVG file
            String s1 = "<polygon points=\"" +  this.s7 +"\" fill =\"" + this.fill + "\" stroke=\"" + this.stroke +"\"/>";
            return s1;
        }
    }
    public class Path : Shape{
        public string s = "";
        public Path(){
        }
        public Path(string s){
            this.s = s;
        }
        public override String Create(){
            String s1 = "<path d=\"" +this.s + "\"/>";
            return s1;
        }         
    }
   
}
