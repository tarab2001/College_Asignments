﻿/*
I have used the Factory Method to add shapes to my canvas. I used this design pattern as we don't know at the beggining
of this program what shape will be added to canvas. The factory method therefore is better to be used. It separates
the production code making it easier to support.
To add styles to the shapes I have used the brodge software desing pattern. I decided to use this pattern as
I felt it was best suited to the requirements of this assignment. It was easy to create the styles once and
add them to the shapes as needed. All shapes have fill colour, stroke colour and stroke width. By creating 
these 3 interfaces it was easy to add differenct styles to each shape in my main class.I thought the bridge 
pattern was best for this assignment as I have many shapes and can independently change the shape or style
Operating System = Windows IDE= VS Code
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace CS264_Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            var r = new Random();
            String s = "";//string we add to SVG file
            Console.WriteLine("Canvas created. Use commands to add shapes to canvas!");//line to prompt user
            ShapeFactory factory = null; //factory created
            String s1 = Console.ReadLine();//read shape from user
            List<Shape> shapes = new List<Shape>();//list to add shapes too
            List<Shape> undoRedo = new List<Shape>(); //list to handle undo/redo
            String SVGOpen = "<svg viewBox=\"0 0 100 100\" + xmlns=\"http://www.w3.org/2000/svg\">";//first line of SVG file
            s = s + SVGOpen;//add to empty string


            while(s1 != "Q"){//take user input while they add shapes
                if(s1.Split(' ')[0] == "A"){
                    String shapeA = s1.Split(' ')[1]; //shape user entered
                    if(shapeA == "Circle"){
                        //get circle info from user
                        int r1 = r.Next(100); //random point
                        int cx = r.Next(100); //random point
                        int cy = r.Next(100); //random point

                        factory = new CircleFactory(r1,cx,cy,new RedColor(),new BlackColor(),new StrokeWidth1()); //call CircleFactory to create Circle
                        Shape redCircle = new Circle(r1,cx,cy,new RedColor(),new BlackColor(),new StrokeWidth1());
                        Shape c1 = factory.GetShape(); //get shape
                        shapes.Add(c1); //add to list
                        Console.WriteLine("Circle (R=" + r1 + ",X=" + cx + ",Y=" + cy + ") added to canvas");
                    }
                    else if (shapeA == "Rectangle"){
                        //get rectangle info from user
                        int x = r.Next(100); //random point
                        int y = r.Next(100); //random point
                        int w = r.Next(100); //random point
                        int h = r.Next(100); //random point

                        factory = new RecFactory(x,y,w,h,new BlueColor(),new BlackColor(),new StrokeWidth2());//call RectangleFactory to create Rect
                        Shape blueRect = new Rec(x,y,w,h,new BlueColor(),new BlackColor(),new StrokeWidth2());
                        Shape r1 = factory.GetShape(); //get shape
                        shapes.Add(r1); //add to list
                        Console.WriteLine("Rectangle (X=" + x + ",Y=" + y + ",W=" + w + ",H=" + h + ") added to canvas");
                    }
                    else if(shapeA == "Ellipse"){
                        //get elipse info from user
                        int rx = r.Next(100); //random point
                        int ry = r.Next(100); //random point
                        int cx = r.Next(100); //random point
                        int cy = r.Next(100); //random point

                        factory = new EllipseFactory(rx,ry,cx,cy,new RedColor(),new WhiteColor(),new StrokeWidth1()); //call EllipseFactory to create Ellipse
                        Shape redEllipse = new Ellipse(rx,ry,cx,cy,new RedColor(),new WhiteColor(),new StrokeWidth1());
                        Shape e1 = factory.GetShape();//get shape
                        shapes.Add(e1); //add to list
                        Console.WriteLine("Ellipse (RX=" + rx + ",RY=" + ry + ",X=" + cx + ",Y=" + cy + ") added to canvas");
                    }
                    else if(shapeA == "Line"){
                        //get line points from user
                        int x1 = r.Next(100); //random point
                        int y1 = r.Next(100); //random point
                        int x2 = r.Next(100); //random point
                        int y2 = r.Next(100); //random point

                        factory = new LineFactory(x1,y1,x2,y2,new BlueColor(),new WhiteColor(),new StrokeWidth1());//call LineFactory to create Line
                        Shape blueLine = new Line(x1,y1,x2,y2,new BlueColor(),new WhiteColor(),new StrokeWidth1());
                        Shape l1 = factory.GetShape();//get shape
                        shapes.Add(l1); //add to list
                        Console.WriteLine("Line (X1=" + x1 + ",Y1=" + y1 + ",X2=" + x2 + ",Y2=" + y2 + ") added to canvas");
                    }
                    else if(shapeA == "Polyline"){
                        //get polyline info from user
                        string points = "";//list of points
                        int listLen = r.Next(10);//number of points
                        for(int i = 0; i < listLen; i++){//add random points to list
                            int a = r.Next(100);
                            int b = r.Next(100);
                            String point = a.ToString() + "," + b.ToString();//convert to string
                            points += " " + point;//add to list
                        }
                        
                        factory = new PolylineFactory(points,new RedColor(),new BlackColor(),new StrokeWidth2());//call PolylineFactory to create Polyline
                        Shape redPol = new Polyline(points,new RedColor(),new BlackColor(),new StrokeWidth2());
                        Shape p1 = factory.GetShape();//get shape
                        shapes.Add(p1);//add to list
                        string string1 = "";
                        foreach(var p in points){
                            string1 = string1 + " " + p; 
                        }
                        Console.WriteLine("Polyline (" + string1 + ") added to canvas");
                    }
                    else if(shapeA == "Polygon"){
                        string points = ""; //list of points
                        int listLen = r.Next(10); //number of points
                        for(int i = 0; i < listLen; i++){ //add random points to list
                            int a = r.Next(100);
                            int b = r.Next(100);
                            String point = a.ToString() + "," + b.ToString(); //convert to string
                            points += " " + point; //add to list
                        }

                        factory = new PolygonFactory(points,new BlueColor(),new WhiteColor(),new StrokeWidth2());//call PolygonFactory to create Poly
                        Shape bluePol = new Polygon(points,new BlueColor(),new WhiteColor(),new StrokeWidth2());
                        Shape pol1 = factory.GetShape();//get shape
                        shapes.Add(pol1);
                        string string2 = "";
                        foreach(var p in points){
                            string2 = string2 + " " + p; 
                        }
                        Console.WriteLine("Polygon (" + string2 + ") added to canvas");
                    }
                    else if(shapeA == "Path"){
                        String path = "";
                        int sLen = r.Next(10);
                        for(int i = 0; i < sLen; i++){
                            int a = r.Next(100);
                            int b = r.Next(100);
                            String path1 = a.ToString() + "," + b.ToString();
                            path += path1;
                        }

                        factory = new PathFactory(path,new RedColor(),new WhiteColor(),new StrokeWidth1());//call PathFactory to create Path
                        Shape redPath = new Path(path,new RedColor(),new WhiteColor(),new StrokeWidth1());
                        Shape p1 = factory.GetShape();//get shape
                        string string2 = "";
                        foreach(var p in path){
                            string2 = string2 + " " + p; 
                        }
                        Console.WriteLine("Path (" + string2 + ") added to canvas");
                    }
                    else{
                        Console.WriteLine("Shape not recognised");
                    }

                }
                else if(s1 == "U"){
                   int len = shapes.Count-1; //length of shape list
                   undoRedo.Add(shapes[len]);//add last shapes to new list
                   shapes.Remove(shapes[len]); //remove shapes from main list
                }
                else if(s1 == "R"){
                    int len = undoRedo.Count-1; //length of undo list
                    shapes.Add(undoRedo[len]); //add last element of undo list to shapes list
                    undoRedo.Remove(undoRedo[len]);//remove shape from undo list
                }
                else if(s1 == "C"){
                    shapes.Clear(); //clear canvas
                }
                else if(s1 == "D"){
                    s = create(shapes);
                    Console.WriteLine(s);
                }
                else if(s1 == "H"){
                    //user menu
                    Console.WriteLine("Commands: ");
                    Console.WriteLine("         H            Help- diplays this message");
                    Console.WriteLine("         A <shape>    Add <shape> to canvas");
                    Console.WriteLine("         U            Undo last operation");
                    Console.WriteLine("         R            Redo last operation");
                    Console.WriteLine("         C            Clear canvas");
                    Console.WriteLine("         D            Display canvas");
                    Console.WriteLine("         Q            Quit application");
                }
                else if(s1 == "S"){
                    s = create(shapes);
                    File.WriteAllText(@"C:\Users\tarab\CS264-Assignment-5\Shapes.SVG", s); //create SVG file
                }
                else{
                    Console.WriteLine("Input not recognsied!!");
                }
                s1 = Console.ReadLine(); //read next line from user
            }
            Console.WriteLine("Goodbye!");
        }

        public static String create(List<Shape> shapes){
            String s = "<svg viewBox=\"0 0 100 100\" + xmlns=\"http://www.w3.org/2000/svg\">";
            foreach (var shape in shapes)
                    {
                        s = s + Environment.NewLine.PadLeft(15) +  shape.Create(); //add shape to string
                    }
                    string SVGClose = "</svg>"; //last line of SVG file
                    s = s + Environment.NewLine + SVGClose; // add closing line to string
            //File.WriteAllText(@"C:\Users\tarab\CS264-Assignment-3\Shapes.SVG", s); //create SVG file
            return s;
        }
    }

    //Product
    public abstract class Shape{
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        public Shape(Color color, Stroke stroke, Stroke_w stroke_W){
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;
        }

        public virtual String Create(){//basic create class
            String s2 = "";
            return s2;

        }
    }

    //ConcreteProducts
    class Circle : Shape{
        public int r;//radius
        public int cx; //center x pos
        public int cy; //center y pos
        string col, stro,strokew;

        public Circle(Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//set r, cx & cy
            r = 10; 
            cx = 10;
            cy = 10;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }
        public Circle(int r, int cx, int cy,Color color,Stroke stroke, Stroke_w stroke_W) : base(color,stroke, stroke_W){ //get r,cx,cy,fill,stroke,stroke-width
            this.r = r;
            this.cx = cx;
            this.cy = cy;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }
        public override String Create(){//create Circle in SVG file
            String s1 = "<circle cx=\"" + this.cx + "\" cy=\"" + this.cy + "\" r=\"" + this.r + "\" fill=\" " + col + "\" stroke =\" " + stro + "\" stroke_width =\" "+strokew + "/>";
            return s1;
        }
    }
    class Rec : Shape{
        public int x; //x pos
        public int y; //y pos
        public int w; //width
        public int h;//height
        string col,stro,strokew;
        public Rec(Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//set x,y,h,w
            x = 10;
            y = 10;
            w = 10;
            h = 10;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }
        public Rec(int x,int y,int w,int h,Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//get x,y,h,w
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }

        public override String Create(){//create Rectangle in SVG file
            String s1 = " <rect x=\""+ this.x + "\" y=\"" + this.y + "\" width=\"" + this.w + "\" height=\"" + this.h + "\" fill=\" " + col + "\" stroke =\" " + stro + "\" stroke_width =\" "+ strokew + "/>";
            return s1;
        }
    }

    class Ellipse : Shape{
        public int rx;//radius x
        public int ry;//radius y
        public int cx;//center x
        public int cy;//center y
        string col,stro,strokew;
        public Ellipse(Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//set rx,ry,cx,cy
            rx = 10;
            ry =10;
            cx = 10;
            cy = 10;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }
        public Ellipse(int rx, int ry, int cx, int cy,Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//get rx,ry,cx,cy
            this.rx = rx;
            this.ry = ry;
            this.cx = cx;
            this.cy = cy;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }

        public override String Create(){//create Ellipse in SVG file
            String s1 = " <ellipse cx=\"" + this.cx + "\" cy=\"" + this.cy + "\" rx=\"" + this.rx + "\" ry=\"" + this.ry + "\" fill=\" " + col + "\" stroke =\" " + stro + "\" stroke_width =\" "+strokew + "/>";
            return s1;
        }
    }

    class Line : Shape{
        public int x1, x2, y1, y2;//points of line
        string col,stro,strokew;
        public Line(Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//set points
            x1 = 10;
            x2 = 20;
            y1 = 10;
            y2 = 20;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }
        public Line(int x1, int x2, int y1, int y2,Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//string s){//get points
            this.x1 = x1;
            this.x2 = x2;
            this.y1 = y1;
            this.y2 = y2;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }

        public override String Create(){//create Line in SVG file
            String s1 = " <line x1=\"" + this.x1 + "\" y1=\"" + this.y1 + "\" x2=\"" + this.x2 + "\" y2=\"" + this.y2 + "\" fill=\" " + col + "\" stroke =\" " + stro + "\" stroke_width =\" "+strokew + "/>";
            return s1;
        }
    }

    class Polyline : Shape{
        public string s5 = ""; //string for points
        string col,stro,strokew;
        public Polyline(Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){ 
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();           
        }
        public Polyline(string l,Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//string s, string s1){//add points from list to string           
            for(int i = 0; i < l.Length; i++){
                this.s5 = this.s5 + " " + l;
            }    
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }

        public override String Create(){//create Polyline in SVG file
            String s1 = "<polyline points=\"" + this.s5 + "\" fill=\" " + col + "\" stroke =\" " + stro + "\" stroke_width =\" "+strokew + "/>"; 
            return s1;
        }
        
    }

    class Polygon : Shape{
        public string s7 = "";//string for points
        string col,stro,strokew;
        public Polygon(Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }

        public Polygon(string l2,Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){//string s, string s1){//add points from list to string
            foreach(var p in l2){
                this.s7 = this.s7 + " " + p;
            }
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }

        public override String Create(){//create Polygon in SVG file
            String s1 = "<polygon points=\"" +  this.s7 + "\" fill=\" " + col + "\" stroke =\" " + stro + "\" stroke_width =\" "+strokew + "/>";
            return s1;
        }
    }
    class Path : Shape{
        public string s = "";
        string col,stro,strokew;
        public Path(Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();
        }
        public Path(string s,Color color, Stroke stroke, Stroke_w stroke_W) : base(color,stroke,stroke_W){
            this.s = s;
            this.col = color.showShapeColor();
            this.stro = stroke.showStrokeColor();
            this.strokew = stroke_W.showStrokeWidth();;
        }
        public override String Create(){
            String s1 = "<path d=\"" +this.s + "\" fill=\" " + col + "\" stroke =\" " + stro + "\" stroke_width =\" "+strokew + "/>";
            return s1;
        }         
    }

    public interface Color
    {
        public string showShapeColor();
    }


    public class BlueColor : Color
    {
        string colb = "";
        public string showShapeColor()
        {
            colb = "blue";
            return colb;
        }
    }


    public class RedColor : Color
    {
        string colr = "";
        public string showShapeColor()
        {
            colr = "red";
            return colr;
        }
    }

    public interface Stroke
    {
        public string showStrokeColor();
    }


    public class BlackColor : Stroke
    {
        string colb = "";
        public string showStrokeColor()
        {
            colb = "black";
            return colb;
        }
    }


    public class WhiteColor : Stroke
    {
        string colw = "";
        public string showStrokeColor()
        {
            colw = "white";
            return colw;
        }
    }

    public interface Stroke_w
    {
        public string showStrokeWidth();
    }


    public class StrokeWidth1 : Stroke_w
    {
        string sw = "";
        public string showStrokeWidth()
        {
            sw = "4";
            return sw;
        }
    }


    public class StrokeWidth2 : Stroke_w
    {
        string sw = "";
        public string showStrokeWidth()
        {
            sw = "4";
            return sw;
        }
    }

    //Creator Class
    abstract class ShapeFactory{
        public abstract Shape GetShape();
    }

    //Concrete Creator Class
    class CircleFactory : ShapeFactory{
        public int _r;//radius
        public int _cx; //center x pos
        public int _cy; //center y pos
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        
        public CircleFactory(int r, int cx, int cy,Color color,Stroke stroke, Stroke_w stroke_W){
            _r = r;
            _cx = cx;
            _cy = cy;
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;
            
        }
        public override Shape GetShape()
        {
            return new Circle(_r,_cx,_cy,color,stroke,stroke_W);
        }

    }

    class RecFactory : ShapeFactory{
        public int _x; //x pos
        public int _y; //y pos
        public int _w; //width
        public int _h; //height
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        
        public RecFactory(int x, int y, int w,int h,Color color,Stroke stroke, Stroke_w stroke_W){
            _x = x;
            _y = y;
            _w = w;
            _h = h;
            
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;
        }
        public override Shape GetShape()
        {
            return new Rec(_x,_y,_w,_h,color,stroke,stroke_W);
        }
    }

    class EllipseFactory : ShapeFactory{
        public int _rx;//radius x
        public int _ry;//radius y
        public int _cx;//center x
        public int _cy;//center y
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        
        public EllipseFactory(int rx, int ry, int cx, int cy,Color color,Stroke stroke, Stroke_w stroke_W){
            _rx = rx;
            _ry = ry;
            _cx = cx;
            _cy = cy;
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;
        }
        public override Shape GetShape()
        {
            return new Ellipse(_rx,_ry,_cx,_cy,color,stroke,stroke_W);
        }

    }
    class LineFactory : ShapeFactory{
        public int _x1, _x2, _y1, _y2;//points of line
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        
        public LineFactory(int x1, int y1, int x2, int y2,Color color,Stroke stroke, Stroke_w stroke_W){
            _x1 = x1;
            _y1 = y1;
            _x2 = x2;
            _y2 = y2;    
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;;
        }
        public override Shape GetShape()
        {
            return new Line(_x1,_y1,_x2,_y2,color,stroke,stroke_W);
        }

    }
    class PolylineFactory : ShapeFactory{
        public string _s5 = ""; //string for points
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        
        public PolylineFactory(string s5,Color color,Stroke stroke, Stroke_w stroke_W){
            _s5 = s5;
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;
        }
        public override Shape GetShape()
        {
            return new Polyline(_s5,color,stroke,stroke_W);
        }

    }
    class PolygonFactory : ShapeFactory{
        public string _s7 = "";//string for points
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        
        public PolygonFactory(string s7,Color color,Stroke stroke, Stroke_w stroke_W){
            _s7 = s7;
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;
        }
        public override Shape GetShape()
        {
            return new Polygon(_s7,color,stroke,stroke_W);
        }

    }
    class PathFactory : ShapeFactory{
        public string _s = "";//string for points
        protected Color color;
        protected Stroke stroke;
        protected Stroke_w stroke_W;
        
        public PathFactory(string s,Color color,Stroke stroke, Stroke_w stroke_W){
            _s = s;
            this.color = color;
            this.stroke = stroke;
            this.stroke_W = stroke_W;
        }
        public override Shape GetShape()
        {
            return new Path(_s,color,stroke,stroke_W);
        }

    }
   
}
