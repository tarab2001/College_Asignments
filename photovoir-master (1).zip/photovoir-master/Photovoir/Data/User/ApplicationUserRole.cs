﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Photovoir.Data.User
{
    public class ApplicationUserRole
    {
        public int ApplicationUserId { get; set; }
        public int ApplicationRoleId { get; set; }
    }
}
