|album			  |year|US_peak_chart_post|	
|-----------------|----|------------------|	
|The White Stripes|1999|-	   		      |	
|De	Stijl		  |2000|-				  |	
|White Blood Cells|2001|61				  |