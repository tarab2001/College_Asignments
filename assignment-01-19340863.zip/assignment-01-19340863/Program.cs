//used Windows laptop with VS Code Version 1.61
using System;
using HtmlAgilityPack;
using System.Text.Json;
using System.IO;
using System.Linq;

namespace CS264{
    class Program{
        static void Main(string[] args){
            String json = ".json";
            String html = ".html";
            String csv = ".csv";
            String md =  ".md";
            
            if(args.Length > 2)
            {
               //Console.WriteLine(args[1]);
               string s = Path.GetExtension(args[1]); //file we want to change
               string s1 = Path.GetExtension(args[3]); //file we want to print out 
               //Console.WriteLine(s);
               //Console.WriteLine(s1);
            
              if(s == json)
              {
                string[] lines = System.IO.File.ReadAllLines(@args[1]); //reads json file
                /* the following is commented out as it gives erros.I was attempting to 
                   create a 2D array from JSON file and then convert to desiered file type
                string[][] data;
                using JsonDocument docJson = JsonDocument.Parse(args[1]);
                JsonElement rootJson = docJson.RootElement;
                for(int i = 0; i < lines.Length-1 ; i++)
                {
                  Console.WriteLine(lines[i]);
                }
                if(s1 == md){
                    mdConv(data);
                }
                else if(s1 == json){
                    jsonConv(data);
                }   
                else if(s1 == csv){
                    csvConv(data);                
                }*/
              }

              if(s == html)
              {
                //string[] lines = System.IO.File.ReadAllLines(@args[1]);
                HtmlDocument doc = new HtmlDocument(); //html document
                doc.LoadHtml(@args[1]); //loads doc we want to change
                string header = "", cols = ""; 
                foreach(HtmlNode table in doc.DocumentNode.SelectNodes("//table")){
                    foreach (HtmlNode row in table.SelectNodes("tr")) //gets the table rows
                    {
                        foreach (HtmlNode cell in row.SelectNodes("th")) //adds headers to string
                        {
                            header += cell.InnerText;
                        }
                        foreach (HtmlNode cell in row.SelectNodes("td")) //adds columns to string
                        {
                            cols += cell.InnerText;
                        }
                    }
                }
                string[][] data = new string[header.Length][]; //2D array to hold table info
                for(int i = 0; i < header.Length; i ++){
                    for(int j = 0; j < cols.Length; j++){
                        data[i][j] = header; //adds headers to array
                    }
                }
                for(int i = 0; i < header.Length; i ++){
                    for(int j = 0; j < cols.Length; j++){
                        data[i][j] = cols; //adds cols to rest of array
                    }
                }
                //calls methos to change 2D array to file type
                if(s1 == md){
                    mdConv(data);
                }
                else if(s1 == json){
                    jsonConv(data);
                }   
                else if(s1 == csv){
                    csvConv(data);                
                }
              }

              if(s == csv)
              {
                //string[] lines = System.IO.File.ReadAllLines(@args[1]);
                string[][] data = File.ReadLines(args[1]).Select(x => x.Split(',')).ToArray(); //splits by , to 2D array
                /*for(int i = 0; i < 4; i++){
                    for(int j = 0; j < 3; j++){
                        Console.WriteLine(data[i][j]);
                    }
                }  */  
                //calls methos to change 2D array to file type
                if(s1 == html){
                    htmlConv(data);
                }  
                else if(s1 == json){
                    jsonConv(data);
                }   
                else if(s1 == md){
                    mdConv(data);                
                }

              }
              if(s == md)
              {
                 //string[] lines = System.IO.File.ReadAllLines(@args[1]);
                 string[][] data = File.ReadLines(args[1]).Select(x => x.Split('|')).ToArray();  //splits by | to 2D aray
                 //Console.WriteLine(data[0][0]);
                 //calls methos to change 2D array to file type
                 if(s1 == html){
                    htmlConv(data);
                }  
                else if(s1 == json){
                    jsonConv(data);
                }   
                else if(s1 == csv){
                    csvConv(data);                
                }
              }
            }
            //checks for other user inputs
            else if(args.Any("v".Contains)){
                Console.WriteLine("VERBOSE MODE");
            }
            else if(args.Any("o".Contains)){
                Console.WriteLine(args[1]);
            }
            else if(args.Any("l".Contains)){
                Console.WriteLine("LIST MODE");
            }
            else if(args.Any("h".Contains)){
                Console.WriteLine("HELP");
            }
            else if(args.Any("i".Contains)){
                Console.WriteLine("INFO");
            }
        }

       static void htmlConv(string[][] data){ //convert 2D array to HTML Table
            Console.WriteLine("<table>");
            Console.WriteLine("      <tr>");
            for(int i = 0; i < data[0].Length; i++){
                Console.WriteLine("          <th>" + data[0][i] + " </th");
            }
            Console.WriteLine("      </tr>");
            for(int i = 1; i < data.Length; i ++){
                Console.WriteLine("      <tr>");
                for(int j = 0; j < data[0].Length; j++){
                    Console.WriteLine("          <td>" + data[i][j] + " </td");
                }
                Console.WriteLine("      </tr>");
            }
            Console.WriteLine("</table>");
            
        }

        static void jsonConv(string[][] data){ //convert 2D array to JSON Object
            Console.WriteLine("[");
           Console.WriteLine("  {");
           for(int i = 0; i < 2; i++)
            {
              Console.WriteLine("    \"" + data[0][i] + "\"" + ": \"" +  data[1][i] + "\",");
            }
            Console.WriteLine("    \"" + data[0][2] + "\"" + ": \"" +  data[1][2] + "\"");
            Console.WriteLine("  },");
            Console.WriteLine("  {");
            for(int i = 0; i < 2; i++)
            {
              Console.WriteLine("    \"" + data[0][i] + "\"" + ": \"" +  data[2][i] + "\",");
            }
            Console.WriteLine("    \"" + data[0][2] + "\"" + ": \"" +  data[2][2] + "\"");
            Console.WriteLine("  },");
            Console.WriteLine("  {");
            for(int i = 0; i < 2; i++)
            {
              Console.WriteLine("    \"" + data[0][i] + "\"" + ": \"" +  data[3][i] + "\",");
            }
            Console.WriteLine("    \"" + data[0][2] + "\"" + ": \"" +  data[3][2] + "\"");
            Console.WriteLine("  },");
           Console.WriteLine("]");

        }
        static void mdConv(string[][] data){//convert 2D array to md file
            for(int i = 0; i < data[0].Length; i++){
                Console.Write("|" + data[0][i]);
            }
            Console.Write("|");
            Console.WriteLine("");
            for(int i = 1; i < data.Length; i ++){
                for(int j = 0; j < data[0].Length; j++){
                    Console.Write("|" + data[i][j]);
                }
            Console.Write("|");  
            Console.WriteLine("");
            }

        }
        static void csvConv(string[][] data){//convert 2D array to CSV file
            for(int i = 0; i < data[0].Length; i++){
                Console.Write("\"" + data[0][i] + "," + "\"");
            }
            Console.WriteLine("");
            for(int i = 1; i < data.Length; i ++){
                for(int j = 0; j < data[0].Length; j++){
                    Console.Write("\"" + data[i][j] + ", " + "\"");
                }  
            Console.WriteLine("");
            }
        }
    }
}